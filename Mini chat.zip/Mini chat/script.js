var mensajes = [
    "Hola, ¿cómo puedo ayudarte?",
    "Elije una opción o escríbeme qué estás buscando\nA. Mi semana\nB. Microprestamos\nC. Más temas"
]; 

function inicializarChat() {
    var areaChat = document.getElementById('chat-box');
    
    mensajes.forEach(function (textoMensaje) {
        var nuevoMensaje = document.createElement('div');
        nuevoMensaje.className = 'mensaje';
        nuevoMensaje.textContent = 'Bot: ' + textoMensaje;
        areaChat.appendChild(nuevoMensaje);
    });
}

function enviarMensaje() {
    var inputMensaje = document.getElementById('message-input');
    var textoMensajeUsuario = inputMensaje.value;

    if (textoMensajeUsuario.trim() === '') {
        return;
    }

    var areaChat = document.getElementById('chat-box');
    var mensajeUsuario = document.createElement('div');
    mensajeUsuario.className = 'mensaje';
    mensajeUsuario.textContent = 'Tú: ' + textoMensajeUsuario;

    areaChat.appendChild(mensajeUsuario);
    inputMensaje.value = '';

    setTimeout(function () {
        var mensajeBot = document.createElement('div');
        mensajeBot.className = 'mensaje';
        mensajeBot.textContent = 'Bot: ' + obtenerRespuestaBot(textoMensajeUsuario);
        areaChat.appendChild(mensajeBot);
        areaChat.scrollTop = areaChat.scrollHeight;
    }, 500);
}

function obtenerRespuestaBot(mensajeUsuario) {
    if (mensajeUsuario.includes("A")) {
        return "El jueves tienes clase de Repostería a las 16hs";
    } else if (mensajeUsuario.includes("B")) {
        return "No puedes pedir un préstamo, aún no has terminado tu primer curso";
    } else if (mensajeUsuario.includes("C")) {
        return "D. Nuevos cursos\nE. Mis certificados\nF. Más temas";
    } else {
        return "Procedo a derivarte con una persona, ya que no puedo ayudarte";
    }
}

document.addEventListener('DOMContentLoaded', function () {
    inicializarChat();
});
